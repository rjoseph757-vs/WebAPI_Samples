Source code accompanying the videos https://youtu.be/ZubGYVHTI3Q, https://youtu.be/l8yepSs_Pk8 and https://youtu.be/xfXX9Gu_cpE

Server repository at  https://github.com/JasperKent/WebApi-Authentication

RESTful web services need securing just as much as any other web site. Here's a first look at how we can use JSON Web Tokens (JWTs) to secure ASP.NET Web API applications.
